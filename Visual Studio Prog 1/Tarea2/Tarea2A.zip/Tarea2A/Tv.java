package Tarea2.Tarea2A;

public class Tv {

    String marca;
    String precio;
    String resolucion;
    String color;
    

    public String encender(){
        return "ENCENDIDA";
    }
    
    public String apagar(){
        return "APAGADA";
    }
    public String cambiar(){
        return "CAMBIANDO EL CANAL";
    }
    public String navegar(){
        return "NAVEGANDO";
    }
}

