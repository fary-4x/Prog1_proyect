package Tarea2.TareaB;

public class Calculadora {
    
    //SUMA//
    public int sumar (int a, int b){
        return a + b;
    }
    public int sumar (int a, int b, int c){
        return a + b + c;
    }
    public int sumar (int a, int b, int c, int d){
        return a + b + c + d;
        
    }
    
    //RESTA//
    public int restar (int a, int b){
        return a - b;
    }
    public int restar (int a, int b, int c){
        return a - b - c;
    }
    public int restar (int a, int b, int c, int d){
        return a - b - c - d;
    }
    
    //MULTIPLICACION//
    public int multiplicar (int a, int b){
        return a * b ;
    }
    public int multiplicar (int a, int b, int c){
        return a * b * c;
    }
    public int multiplicar (int a, int b, int c, int d){
        return a * b * c * d;
    }
    
    //DIVISION//
    public int dividir (int a, int b){
        return a / b;
    }
    
    }
    
    
