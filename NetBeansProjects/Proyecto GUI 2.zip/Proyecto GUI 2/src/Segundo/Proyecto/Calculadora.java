
package Segundo.Proyecto;

public class Calculadora {
    
//SUMA
    public int sumar (int a, int b){
        return a + b;
    }
    
 //RESTA
    public int restar (int a, int b){
        return a - b;
    }
    
//MULTIPLICACION
    public int multiplicar (int a, int b){
        return a * b ;
    }
    
//DIVISION
    public int dividir (int a, int b){
        return a / b;
    }
    
    
}
