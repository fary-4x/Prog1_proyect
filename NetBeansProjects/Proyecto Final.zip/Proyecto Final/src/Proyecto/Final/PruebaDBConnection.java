package Proyecto.Final;

public class PruebaDBConnection {

    public static void main(String[] args) {
        DBConnection db = new DBConnection();
        db.getConnection();

    }
}
